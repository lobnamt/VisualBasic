﻿Public Class Test1
    Public Score As Integer = 0




    Private Sub btnQ2_Click(sender As Object, e As EventArgs) Handles btnQ2.Click

        'Adds to the score of the answer is right. If the text box is empty gives a message box
        'informing the user to provide an answer.

        txtQ1.Text = txtQ1.Text.ToLower()
        txtQ2.Text = txtQ2.Text.ToLower()


        If txtQ1.Text = "select * from customers;" Then
                Score += 1
            End If

        If txtQ2.Text = "select cust_id from customers;" Then
            Score += 1
        End If


        If txtQ1.Text = "" Then
            MessageBox.Show("Please Answer Question 1")
        ElseIf txtQ2.Text = "" Then
            MessageBox.Show("Please Answer Question 2")
        Else
            Me.Hide()
            Test2.ShowDialog()
        End If

    End Sub

    Private Sub btnCheckAnswer1_Click(sender As Object, e As EventArgs) Handles btnCheckAnswer1.Click

        'Makes the text boxes in lower case then checks the answer and 
        'colors the text in green if it's right and red if its wrong

        txtQ1.Text = txtQ1.Text.ToLower()
        txtQ2.Text = txtQ2.Text.ToLower()
        If txtQ1.Text = "select * from customers;" Then
            txtQ1.ForeColor = Color.Green
        Else
            txtQ1.ForeColor = Color.Red
        End If

        If txtQ2.Text = "select cust_id from customers;" Then
            txtQ2.ForeColor = Color.Green
        Else
            txtQ2.ForeColor = Color.Red

        End If
        'Else
        'MessageBox.Show("You can only check your answer two times!")
        'End If
    End Sub


End Class