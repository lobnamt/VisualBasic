﻿Public Class first_page


    Private Sub btnStart_Click(sender As Object, e As EventArgs) Handles btnStart.Click
        Me.Hide()
        Learn1.ShowDialog()

    End Sub


End Class
