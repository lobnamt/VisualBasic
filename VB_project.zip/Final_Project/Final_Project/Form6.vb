﻿Public Class Finish
    Private Sub Label1_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Form6_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        lblScore.Text = "Congratualtions you scored " & Test1.Score & "/6"

    End Sub

End Class