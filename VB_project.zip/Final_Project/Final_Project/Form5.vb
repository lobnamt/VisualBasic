﻿Public Class Test3

    Private Sub btnFinal_Click(sender As Object, e As EventArgs) Handles btnFinal.Click
        txtAnswer5.Text = txtAnswer5.Text.ToLower()
        txtAnswer6.Text = txtAnswer6.Text.ToLower()


        If txtAnswer5.Text = "a" Then
            Test1.Score += 1
        End If


        If txtAnswer6.Text = "select cust_address, cust_city, cust_state from customers;" Then
            Test1.Score += 1
        End If

        If txtAnswer5.Text = "" Then
            MessageBox.Show("Please Answer Question 5")
        ElseIf txtAnswer6.Text = "" Then
            MessageBox.Show("Please Answer Question 6")
        ElseIf Test1.Score >= 4 Then
            Me.Hide()
            Finish.ShowDialog()
        ElseIf Test1.Score < 4 Then
            MessageBox.Show("Unfortunately, you scored less than 4/6")
        End If

    End Sub


    Private Sub btnCheckAnswer3_Click(sender As Object, e As EventArgs) Handles btnCheckAnswer3.Click
        txtAnswer5.Text = txtAnswer5.Text.ToLower()
        txtAnswer6.Text = txtAnswer6.Text.ToLower()


        If txtAnswer5.Text = "a" Then
            txtAnswer5.ForeColor = Color.Green
        Else
            txtAnswer5.ForeColor = Color.Red
        End If

        If txtAnswer6.Text = "select cust_address, cust_city, cust_state from customers;" Then
            txtAnswer6.ForeColor = Color.Green
        Else
            txtAnswer6.ForeColor = Color.Red
        End If
    End Sub
End Class