﻿Public Class Learn1


    Private Sub btnTest1_Click(sender As Object, e As EventArgs) Handles btnTest1.Click
        Test1.ShowDialog()
    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click

    End Sub
End Class