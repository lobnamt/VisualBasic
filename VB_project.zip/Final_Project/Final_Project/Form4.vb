﻿Public Class Test2

    Private Sub btnQ3_Click(sender As Object, e As EventArgs) Handles btnQ3.Click

        'Increase the score by 1 if rdo2 and chk1 and chk2 are checked. 
        ' If none of them are checked display a message box informing the user to Answer the questions.

        If rdo2.Checked Then
            Test1.Score += 1
        End If

        If chk1.Checked And chk2.Checked Then
            Test1.Score += 1
        End If

        'Move to the next form (Q5 and Q6)
        If Not rdo1.Checked And Not rdo2.Checked And Not rdo3.Checked Then
            MessageBox.Show("Please Answer Question 3")

        ElseIf Not chk1.Checked And Not chk2.Checked And Not chk3.Checked Then
            MessageBox.Show("Please Answer Question 4")
        Else
            Me.Hide()
            Test3.ShowDialog()
        End If
    End Sub



    Private Sub btnCheckAnswer2_Click(sender As Object, e As EventArgs) Handles btnCheckAnswer2.Click

        ' This button checks the answer by displaying a message box of what is right and wrong.

        If rdo2.Checked And chk1.Checked And chk2.Checked And Not (chk3.Checked) Then
            MessageBox.Show("Your Answer is Correct")
        ElseIf Not rdo2.Checked Then
            MessageBox.Show("Revise Question 3")
        ElseIf chk3.Checked Or Not (chk2.Checked And chk1.Checked) Then
            MessageBox.Show("Revise Question 4")
        Else
            MessageBox.Show("Revise Question 3 and 4")

        End If
    End Sub
End Class